# DIO - Desafio Open Source

Este repositório foi criado como parte do desafio de contribuição open source proposto pela DIO (Digital Innovation One).

## Objetivo

Praticar o fluxo de fork, commit, pull request e contribuição com projetos reais.

## Participante

- [Maykon Teixeira](./profiles/maykonsilva.md)
