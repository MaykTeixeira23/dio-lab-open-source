# Maykon Teixeira 👋

Olá! Sou estudante de Análise e Desenvolvimento de Sistemas e essa é minha primeira contribuição em um projeto Open Source. 🚀

- 💻 Apaixonado por tecnologia e programação.
- 🎯 Estudando lógica de programação, Git/GitHub e desenvolvimento web.
- 📚 Em busca constante de novos conhecimentos!

Muito feliz por fazer parte da comunidade de desenvolvedores da DIO. 💙
